<?php
$teacher_id = $_POST['teacher_id'];
include '../../database/config.php';
$fname = ucwords(mysqli_real_escape_string($conn, $_POST['fname']));
$lname = ucwords(mysqli_real_escape_string($conn, $_POST['lname']));
$email = mysqli_real_escape_string($conn, $_POST['email']);
$phone = mysqli_real_escape_string($conn, $_POST['phone']);
$department = mysqli_real_escape_string($conn, $_POST['department']);
$category = mysqli_real_escape_string($conn, $_POST['category']);
$address = ucwords(mysqli_real_escape_string($conn, $_POST['address']));
$dob = mysqli_real_escape_string($conn, $_POST['dob']);
$gender = mysqli_real_escape_string($conn, $_POST['gender']);

$sql = "SELECT * FROM tbl_users WHERE email = '$email' AND user_id !='$teacher_id' OR phone = '$phone' AND user_id !='$teacher_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
    $sem = $row['email'];
	$sph = $row['phone'];
	if ($sem == $email) {
	 header("location:../edit-teacher.php?rp=1189&tid=$teacher_id");	
	}else{
	
	if ($sph == $phone) {
	 header("location:../edit-teacher.php?rp=2074&tid=$teacher_id");	
	}else{
		
	}
	
	}
	
    }
} else {

$sql = "UPDATE tbl_users SET first_name = '$fname', last_name = '$lname', gender = '$gender', dob = '$dob', address = '$address', email = '$email', phone = '$phone', department = '$department', category = '$category' WHERE user_id='$teacher_id'";

if ($conn->query($sql) === TRUE) {
  header("location:../edit-teacher.php?rp=7643&tid=$teacher_id");
} else {
  header("location:../edit-teacher.php?rp=1298&tid=$teacher_id");
}


}

$conn->close();
?>
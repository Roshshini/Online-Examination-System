<?php
include '../../database/config.php';
$tid = mysqli_real_escape_string($conn, $_GET['id']);

$sql = "UPDATE tbl_users SET acc_stat='0' WHERE user_id='$tid'";

if ($conn->query($sql) === TRUE) {
    header("location:../teachers.php?rp=6633");
} else {
    header("location:../teachers.php?rp=1298");
}

$conn->close();
?>

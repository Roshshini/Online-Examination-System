<?php
include '../../database/config.php';
$trid = mysqli_real_escape_string($conn, $_GET['id']);

$sql = "DELETE FROM tbl_users WHERE user_id='$trid'";

if ($conn->query($sql) === TRUE) {
    header("location:../teachers.php?rp=7830");
} else {
    header("location:../teachers.php?rp=1298");
}

$conn->close();
?>

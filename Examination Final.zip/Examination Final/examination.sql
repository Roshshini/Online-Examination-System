-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2020 at 08:47 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `examination`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_alerts`
--

CREATE TABLE `tbl_alerts` (
  `id` int(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_alerts`
--

INSERT INTO `tbl_alerts` (`id`, `code`, `description`) VALUES
(1, '9275', 'Department was added successfully'),
(2, '1185', 'Duplicate record found'),
(3, '5426', 'Could not add department'),
(4, '7823', 'Settings applied successfully'),
(5, '1298', 'Could not apply settings'),
(6, '1289', 'Category was added successfully'),
(7, '7732', 'Could not add category'),
(8, '3598', 'Subject was added successfully'),
(9, '1925', 'Could not add subject'),
(10, '6310', 'Student was added successfully, default password is 123456'),
(11, '9157', 'Could not register student'),
(12, '2074', 'Duplicate phone number found'),
(13, '1189', 'Duplicate email found'),
(14, '2932', 'Examination was added successfully'),
(15, '7788', 'Could not add examination'),
(16, '0357', 'New question was added successfully'),
(17, '3903', 'Could not add question'),
(18, '9174', 'Notice was added successfully'),
(19, '6389', 'Could not add notice'),
(20, '9135', 'You must be admin to access the control panel'),
(21, '9422', 'You must login first'),
(22, '0912', 'Invalid username or password'),
(23, '9122', 'You must be a student to acces the exams'),
(24, '5732', 'Your account has been disabled'),
(25, '8924', 'Account not found'),
(26, '1804', 'New password has been sent to you through your email'),
(27, '1100', 'Could not reset your password'),
(28, '6311', 'Teacher was added successfully, default password is 123456'),
(29, '9158', 'Could not register teacher'),
(30, '9137', 'You must be teacher to access the control panel'),
(31, '7825', 'Drop exam successfully'),
(32, '6632', 'Activated successfully'),
(33, '6633', 'Inactivated successfully'),
(34, '7826', 'Drop department successfully'),
(35, '7827', 'Drop category successfully'),
(36, '7828', 'Drop subject successfully'),
(37, '7829', 'Drop student successfully'),
(38, '4352', 'New password updated'),
(39, '5627', 'Exam activated'),
(40, '7830', 'Drop teacher successfully'),
(41, '7643', 'Updated new details'),
(42, '7831', 'Drop notice successfully'),
(43, '7641', 'Updated Password');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assessment_records`
--

CREATE TABLE `tbl_assessment_records` (
  `record_id` varchar(255) NOT NULL,
  `student_id` varchar(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `exam_name` varchar(255) NOT NULL,
  `exam_id` varchar(255) NOT NULL,
  `score` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `next_retake` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_assessment_records`
--

INSERT INTO `tbl_assessment_records` (`record_id`, `student_id`, `student_name`, `exam_name`, `exam_id`, `score`, `status`, `next_retake`, `date`) VALUES
('RS04062477034704', 'S050-094-220', 'Jeremiah Mapunda', 'Ms Office Tools', 'EX-127128', '75', 'PASS', '01/03/2018', '12/19/2017'),
('RS25704228520703', 'admin', 'Roshshini Subramaniam', '', 'EX-261479', '0', 'FAIL', '', ''),
('RS27879572257049', 'S604-119-649', 'Sasi Muni', 'Ms Office Tools', 'EX-127128', '0', 'FAIL', '01/11/2020', '12/27/2019'),
('RS30447236986153', 'S301-241-117', 'Abc Def', 'Ms Office Tools', 'EX-127128', '95', 'PASS', '01/07/2018', '12/23/2017'),
('RS36261661802284', 'S938-591-996', 'Rosh Cd', 'Auto CAD Quiz', 'EX-744741', '0', 'FAIL', '12/16/2019', '12/12/2019'),
('RS45897591463115', 'S159-023-627', 'D D', 'Sas', 'EX-100243', 'NAN', 'FAIL', '12/29/2019', '12/27/2019'),
('RS58967348182380', 'S432-914-994', 'Amne Thinay', 'Ms Office Tools', 'EX-127128', '80', 'PASS', '01/02/2018', '12/18/2017'),
('RS69371224813619', 'S639-647-028', 'Abc Def', 'Auto CAD Quiz', 'EX-744741', '0', 'FAIL', '12/25/2017', '12/21/2017'),
('RS73341763461355', 'S746-849-932', 'Azizi Daudy', 'Ms Office Tools', 'EX-127128', '15', 'FAIL', '01/03/2018', '12/19/2017'),
('RS97822805811823', 'S827-143-545', 'Aa A', 'Auto CAD Quiz', 'EX-744741', '75', 'PASS', '01/05/2020', '01/01/2020');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_categories`
--

CREATE TABLE `tbl_categories` (
  `category_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `date_registered` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_categories`
--

INSERT INTO `tbl_categories` (`category_id`, `name`, `department`, `date_registered`, `status`) VALUES
('CT-238600', 'Biomedical Diploma', 'Biomedical', '03-01-2020', 'Active'),
('CT-312715', 'HR Foundation', 'Human Resources', '03-01-2020', 'Active'),
('CT-324162', 'Electrical E Phd', 'Electrical Engineering', '03-01-2020', 'Active'),
('CT-534923', 'Civil Engineering Diploma', 'Civil Engineering', '03-01-2020', 'Active'),
('CT-565369', 'Computer Science Diploma', 'Computer Science', '03-01-2020', 'Active'),
('CT-604232', 'Philosophy Phd', 'Philosophy', '03-01-2020', 'Active'),
('CT-646705', 'Earth Science Master', 'Earth Sciences', '03-01-2020', 'Active'),
('CT-840545', 'Chemical Eng Degree', 'Chemical Engineering', '03-01-2020', 'Active'),
('CT-889401', 'Biometric Cerificate', 'Biometric ', '15-04-2020', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_departments`
--

CREATE TABLE `tbl_departments` (
  `department_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date_registered` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_departments`
--

INSERT INTO `tbl_departments` (`department_id`, `name`, `date_registered`, `status`) VALUES
('DP-030059', 'Computer Science', '10-12-2017', 'Active'),
('DP-152240', 'Civil Engineering', '10-12-2017', 'Active'),
('DP-208765', 'Biometric ', '15-04-2020', 'Active'),
('DP-254881', 'Mining Engineering', '10-12-2017', 'Active'),
('DP-280518', 'Human Resources', '23-12-2019', 'Active'),
('DP-429345', 'Earth Sciences', '10-12-2017', 'Active'),
('DP-435440', 'Zz', '20-04-2020', 'Active'),
('DP-634956', 'Chemical Engineering', '10-12-2017', 'Active'),
('DP-729904', 'Electrical Engineering', '10-12-2017', 'Active'),
('DP-787794', 'Biomedical', '10-12-2017', 'Active'),
('DP-835457', 'History Of Art', '10-12-2017', 'Active'),
('DP-910585', 'Philosophy', '10-12-2017', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_examinations`
--

CREATE TABLE `tbl_examinations` (
  `exam_id` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `exam_name` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `duration` int(255) NOT NULL,
  `passmark` int(255) NOT NULL,
  `re_exam` int(255) NOT NULL,
  `terms` longtext NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_examinations`
--

INSERT INTO `tbl_examinations` (`exam_id`, `category`, `subject`, `exam_name`, `date`, `duration`, `passmark`, `re_exam`, `terms`, `status`) VALUES
('EX-570149', 'Biomedical Diploma', 'Biomedical Science', 'Biomedical Science', '05/23/2020', 120, 45, 3, 'Students do not copy other\'s  paper. If we catch you will be fail the exam on the spot.', 'Active'),
('EX-769751', 'Biomedical Diploma', 'Biology', 'Biology-Cell Tissue', '04/18/2020', 60, 40, 3, 'Sdsdsdsad', 'Active'),
('EX-781968', 'Computer Science Diploma', 'Information Technology', 'IT I', '05/16/2020', 120, 45, 3, 'Students do not copy other\'s  paper. If we catch you will be fail the exam on the spot.', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notice`
--

CREATE TABLE `tbl_notice` (
  `id` int(255) NOT NULL,
  `notice_id` varchar(255) NOT NULL,
  `post_date` varchar(255) NOT NULL,
  `last_update` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_notice`
--

INSERT INTO `tbl_notice` (`id`, `notice_id`, `post_date`, `last_update`, `description`, `title`) VALUES
(1, 'NT-60920607', '19/12/2017 01:16:53', '24/01/2020 10:50:37', 'every student is required to take his/her assessment on time, fail to do that the instructor wont re-enable the assessment again', 'Assessments'),
(2, 'NT-38754332', '01/01/2020 07:35:12', '01/01/2020 07:35:49', 'Student do not allow to bring  any noted in the exam hall....', 'Important Notice');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_questions`
--

CREATE TABLE `tbl_questions` (
  `question_id` varchar(255) NOT NULL,
  `exam_id` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `question` longtext NOT NULL,
  `option1` varchar(255) NOT NULL DEFAULT '-',
  `option2` varchar(255) NOT NULL DEFAULT '-',
  `option3` varchar(255) NOT NULL DEFAULT '-',
  `option4` varchar(255) NOT NULL DEFAULT '-',
  `answer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_questions`
--

INSERT INTO `tbl_questions` (`question_id`, `exam_id`, `type`, `question`, `option1`, `option2`, `option3`, `option4`, `answer`) VALUES
('QS-008805', 'EX-570149', 'FB', 'The part of the brain connecting the spinal cord with the forebrain and the cerebrum', '-', '-', '-', '-', 'Brain Stem'),
('QS-062759', 'EX-570149', 'MC', 'The part of the nervous system that consists of the brain and the spinal cord', 'Central Nervous System', 'Cerebellum', 'Hypothalamus', 'Thalamus', 'option1'),
('QS-062902', 'EX-769751', 'FB', 'These are responsible for cell locomotion and the cells structural characteristics', '-', '-', '-', '-', 'Microfilaments'),
('QS-063074', 'EX-570149', 'MC', 'Hearing loss or impairment resulting from exposure to loud sound is called noise-induced hearing loss', 'True', 'False', '', '', 'option1'),
('QS-081578', 'EX-781968', 'FB', 'ALU stands for __________.', '-', '-', '-', '-', 'Arithmetic logic unit'),
('QS-100679', 'EX-570149', 'MC', 'A neuron is a nerve cell; the fundamental unit of the nervous system', 'True', 'False', '-', '-', 'option1'),
('QS-152491', 'EX-570149', 'FB', 'Which of the following is the most easily detected of the tastes?', '-', '-', '-', '-', 'Bitter'),
('QS-192585', 'EX-570149', 'MC', 'A large projecting part of the brain, which is responsible for coordination, situated between the brain stem and the back of the cerebrum', 'Optic Chiasm', 'Optic Nerve', 'Cerebellum', 'Brain Stem', 'option3'),
('QS-214927', 'EX-781968', 'FB', 'Full form of PC', '-', '-', '-', '-', 'Personal computer'),
('QS-216632', 'EX-781968', 'MC', 'Which of the following is a part of the Central Processing Unit?', 'Printer', 'Key board', 'Mouse	', 'Arithmetic & Logic Unit  ', 'option4'),
('QS-258031', 'EX-570149', 'MC', 'The system of the body that is made up of the brain, spinal cord, and nerves that receives and interprets stimuli and transmits impulses to organs', 'Circulatory System', 'Skeletal System', 'Nervous System', 'Muscular System', 'option3'),
('QS-283132', 'EX-769751', 'MC', 'A primary function of lipids in organisms is', 'Component of a cell membrane', 'Energy', 'Hormones', 'All of  these', 'option1'),
('QS-307436', 'EX-781968', 'FB', 'ROM stands for', '-', '-', '-', '-', 'Read only Memory'),
('QS-356179', 'EX-570149', 'MC', 'This part of the eye transmits impulses to the brain from the retina at the back of the eye.', 'Optic Nerve', 'Retina', 'Cones', 'Rods', 'option1'),
('QS-482582', 'EX-769751', 'MC', 'Biology is a study of', 'Research', 'Living Things', 'Ecology and Evolution', 'None of the above', 'option2'),
('QS-491239', 'EX-769751', 'MC', 'Nucleic acids are composed of repeating units of', 'Amino acids', 'Carbon', 'Nucleotides', 'Fatty acids', 'option3'),
('QS-508982', 'EX-570149', 'FB', 'A rare change in the DNA of a gene_________________', '-', '-', '-', '-', 'Mutation'),
('QS-522626', 'EX-769751', 'MC', 'Enzymes ', 'Compose much of th physical structure and framework of an organism', 'Are proteins', 'Are composed of repeating subunits of mono saccharides', 'Form part of the most complex nucleic acids', 'option2'),
('QS-524563', 'EX-781968', 'FB', 'A byte can hold one _____ of data', '-', '-', '-', '-', 'Character'),
('QS-567354', 'EX-570149', 'MC', 'A double-stranded molecule that determines the inherited structure of a cell\'s proteins is DNA', 'True', 'False', '-', '-', 'option1'),
('QS-581692', 'EX-781968', 'MC', 'Chief Component of first generation computer was ?', 'Transistors ', 'Vacuum Tubes and Valves', 'Integrated Circuit	', 'Semiconductor', 'option2'),
('QS-603072', 'EX-781968', 'MC', 'Which of the following is an output device?', 'Scanner', 'Printer ', 'Flat screen', 'Touch Screen', 'option2'),
('QS-674913', 'EX-769751', 'MC', 'The entire surface of the earth that contains living organisms is called the', 'Biosphere', 'Environment', 'Atmosphere', 'Universe', 'option1'),
('QS-688593', 'EX-769751', 'MC', 'Which of these units is most suitable for measuring the length of a cell?', 'Kilometre	 ', 'Metre', 'Centimetre', 'Micrometre', 'option4'),
('QS-723397', 'EX-781968', 'FB', '________ bits equal one byte.', '-', '-', '-', '-', 'Eight'),
('QS-759415', 'EX-781968', 'MC', 'Which of the following is the correct order of the four major functions of a computer?', 'Process, Output, Input, Storage', 'Input, Output, Process, Storage', 'Process, Storage, Input, Output', 'Input, Process, Output, Storage', 'option4'),
('QS-761251', 'EX-781968', 'MC', 'Which of the following is the largest unit of storage?', 'GB	', 'KB', 'MB', 'TB', 'option1'),
('QS-785974', 'EX-769751', 'MC', 'A 6-carbon simple sugar that forms long chains of carbohydrates such as starch and cellulose is', 'Sucrose', 'Glucose', 'Amino acids', 'Disaccharides', 'option2'),
('QS-863708', 'EX-769751', 'FB', 'A lipid bilayer _____________ fatty acids tails face each other within a region that excludes water', '-', '-', '-', '-', 'Hydrophobic'),
('QS-921029', 'EX-769751', 'FB', 'The structure in a cell that controls the cell\'s activities is called the _________', '-', '-', '-', '-', 'Nucleus');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subjects`
--

CREATE TABLE `tbl_subjects` (
  `subject_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `date_registered` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subjects`
--

INSERT INTO `tbl_subjects` (`subject_id`, `name`, `department`, `category`, `date_registered`, `status`) VALUES
('SB-002589', 'Cost Accounting', 'Human Resources', 'HR Foundation', '03-01-2020', 'Active'),
('SB-266798', 'Fluid Dynamics', 'Chemical Engineering', 'Chemical Eng Degree', '03-01-2020', 'Active'),
('SB-381531', 'Metrology', 'Electrical Engineering', 'Electrical E Phd', '03-01-2020', 'Active'),
('SB-461185', 'Structural Analysis III', 'Civil Engineering', 'Civil Engineering Diploma', '03-01-2020', 'Active'),
('SB-652423', 'Biometric Level 1', 'Biometric ', 'Biometric Cerificate', '15-04-2020', 'Active'),
('SB-695060', 'Information Technology', 'Computer Science', 'Computer Science Diploma', '03-01-2020', 'Active'),
('SB-695564', 'Biomedical Science', 'Biomedical', 'Biomedical Diploma', '03-01-2020', 'Active'),
('SB-866660', 'Biology', 'Earth Sciences', 'Earth Science Master', '03-01-2020', 'Active'),
('SB-876569', 'Epistemology', 'Philosophy', 'Philosophy Phd', '03-01-2020', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `address` longtext NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL DEFAULT '-',
  `category` varchar(255) NOT NULL DEFAULT '-',
  `login` varchar(255) DEFAULT 'e10adc3949ba59abbe56e057f20f883e',
  `role` varchar(255) DEFAULT NULL,
  `avatar` longblob,
  `acc_stat` varchar(255) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `first_name`, `last_name`, `gender`, `dob`, `address`, `email`, `phone`, `department`, `category`, `login`, `role`, `avatar`, `acc_stat`) VALUES
('admin', 'Roshshini', 'Subramaniam', 'Female', '23/04/1997', '-', 'Roshshini2304@gmail.com', '144342356', '-', '-', '827ccb0eea8a706c4c34a16891f84e7b', 'admin', 0xffd8ffe000104a46494600010100000100010000ffdb008400090607131312151313131615151717171a18171817171717171717151718171718151d1d2820181a251b171521312125292b2e2e2e171f3338332d37282d2e2b010a0a0a0e0d0e1b10101a2d2520252d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2dffc0001108011300b703012200021101031101ffc4001b00000203010101000000000000000000000405020306000107ffc4003e1000010302030408050204050501000000010002110321040531124151610622718191a1b1f0133242c1d152e1146292f107237282a2243353c2d243ffc400190100030101010000000000000000000000000102030405ffc40023110101000202020203010101000000000000010211032112314161223251421404ffda000c03010002110311003f007ef3a052a54c409510dbab65716daebb0d8a11a2ae8394eb36755263149a2e56d25172f744a9aef8aa388369558b95d5c18ba7057b4c98445182aac2b64298ac1b36da23fa4769f64a78f7eca4a39948469aeede7b948614700def8fc25e6ad575f6b607281e2e3efb10588a74bea76d1e7b4ffbfdd69bfe2a6276dc309b54683c03a7c8d94ab65a48f99b3c74fd967a98668d63c9fe568ffe958ecd1f4625b50377cb411de249011e5fd3f17b9836ae1fad0638ead3de9be499d36bb764fcc077a006741c245c7d4dd5ae1c4734b2a516b2a0ab4ac245870371dc96f5e8fc77d539cd8d4046c5c687711bc210578d75dfc7c133a4f0f24e880cd30ed758d89d0ee9eddc56959fd21f101120a931d6ba4b84aee6bcb1d63ea9bb2a07357359aa2a5b678ab5aeb590cc741526ea8bd94e960a8572aeabaeb906269dc4a8b1a54834a902aefa28a2ad3b2ea6c302516c6594c539b29915419a7755b917535854962566ce23876dd5b5a3ead17506c15e63df713a0049edd1bf7f0553d17b0d5eb434df618353bfb3b55342b00d0f78d96eb4e9ef3fcce3c79a19ce0f3b6fff00b6cd07ea77defeec83ab5dd55f1cc5b8f0681c05bc938bd0e7577d57757bb80ec1b935a596d3a4df8958db86a49e1c67b15d80c2b30f4cd5a90207b0162335e9455c4d52da42182c2df720f9276e8e4b97a34cdfa4ed03669d2706f0f94f6c4fee921c5baa9b170e172476107d532cb722261cf2494fa8e4ed1b94ead69248cfe028b858fbf76f04d30d4b926630606e5efc000a24174f70862fb91388a4c7b4b4e846fe6a835804b7135db3af9ad265a65963b0598e01ec703f306c43b525ba41e611741f03b55f86c48169b111074ed4055696c00644c4f259e5da33826abe0cab28d4b8415773b7852c2d49852cf62de6e572aab3b5217a8d99dd1a7d55506dd5a2a6e501c15e4a4c2f29132bda2d5228d1bcaacbcaa2a36eae7ba50ef3a293581ba7341e68dda3130379e43d9f146baa06364ebb82cc74833022403dbef92aba90f19ba1336c7cc35b668b01c770b712539e8c60621c753373ff00277bfbacc65940d47833a7aad853c40632dc3fe23f3f84b1bf35794f8855d36cc0d422830f57ddcf9abba3d94318d1649b09352b179de67df82d96069c04b1fcb2dd6d678e3a134da02b4be15642f085bb256fad755547cab4b021dea69c2ec6cb41292e2719ef827d980eaacad6d758f7a158e5149b71ced366dc6536c2be59cc798e495e185e0d8fbd1d09960a86cddafdae5b4091dda8ec4f5f2caf7d0d38810277aa2b437ae3c17989d445afa2af1733c884561a5a2a6d4f72e54e13521725434345d2ae78dea9a4cb5910e78566b29bd582105b6ae7be20a7b093c80508f12639a9c12578c716827792612bdd38ab18608bdc683876f92c7e6c25f7fc9249b0037ad2621d00b8ea6c94d12d2e2e178face93fca1677badf1e9ee128fc3601f53b5e53cd799de33629c0d5c6dfe90091e312bdc3bc39f3f4b249e67709e6521ce7105d59a26f31c86f36e5d546d5276d0e4985800ad1b2a8035584c7661468b01a95ea071d037527934059d19d35ee1b2ec40e1307c81985a618dd7479e537dd7d73f8ae6a15b1a0059ec8aa3aab475b6b9f14666f857812ab774351d88e9250659cf13bc0ba9e1ba4549ff2b5ee1c6161ce18fc48a4c6979976d3c1206a47895018fccdb7f82c2d1bb676491fd5afe139ba9b64ba7d16a55654169078111e1c564f3fa6698da0247046f47f1d52ac1f84f61fa9ae169e47784cf38c18730cf05194daa31f96e77369ee36f3884edb98d2372208fada6edf3223b42c963b065af9161a0f143e1b125b8a737e910d238f56ff007512d3b84d6dbec4bf43ac8b10a34aa4883aaec13659b3c34ec57d0c24192abdc7265d5578561985c98121a2cb92b086d07985731a0eaab60b4c2e6bc94d4b6b3382ea4d2442b00b85756869080f1cc88e081c5d44654b848333c444f2f7efb919dd2b0c774bb35c6367ac61839dddeca05d8a7be1ad6ec37bb68f76e1eeeafa545a7acf6ed19d4bc868e4045d5cdc4d3a6618d133d6377127b4d87e16731dfb6d6ebd27580a3464c01af69dc4f1597c0b0d6c403e1ea7ec99e66f755324c8d40e3ccfbfb2a3a32f0715b23e96f993efc53b0f0367f4369baa0ac5a5ee1fa8920760d02229f471d3d5a34d838c5fdeab6786200ba9baab4700ba24e85d7f0a729ca0528b0d775823f36c2ed0015d86acd79eadd118c64095524d22d664e40d3bc8ec30aea1d1a6cddce3da54ebe6a293a2a02d9d0ee3de886e64d22c6ca7f15c945330cd608093e6da18471c68e281c410e3653951a647158605c5c63aba723a97782c665dfe6620b87d4e24766efb2619e749daf1529536ba4b9cd738c01b33062fbf8a964385d96edef811f60b2b2e33b55cb6dbe5ec903df24caae9cd23cb9f0dec4c6abc8121563e9cbc93b7576988deb94f0ee9b90b94e5d5286b56a1b885d4b50afa8e1254e910350a824d56370e5da955175d581fde83795e986b0f581b2cbe220bccc18beb61ddbffb2d2e2df223dfbb159ea0c8352a3bf5c30760007dd2cbdaf179570902ff0031d00ddda6d7fca4f8aaf4e90803689df3631c4e804cdbbd35ccab437f99da0e43f7b78acf6219d73be0344f017331ce3d12b57202cef34736997186ce804de74d6e6dd9aacf7427302dc68933b41dde627ec5774a6b9a860683cf8cf80483038b346bb2a0fa1c0c711bc77890b6e3c778d679e571ca3ef6dce06cc829362334756a9f0da4c7d51b87055ff0cdaad0f61eabc0208df22c97d07d5c2b9c5b4be235b7373b51c845d672db74ebdcd74dd617306d0635a58e81a387dd579874a80f95bb478210e67b6c05d49db24482deb08899b72292d66d2da901ee71becc5fc382bb6cf4ce497dc1f5f17571225ec0d03402fe692bdf5289b5dbc3f09a7f155432431b4d9b33b4f3ce3459f185af56b6db9e4531a36009bdce930959b39968c5999b8f14c5b8dd9a4fa87e9639de0d27ec867619a344afa5d8bf878434c1eb552183fd3abcff004823bd678fb3cef4c164b84db7027fbade61a87f9463d859fc8b0f10488d2cb4cd7c30b77ba40f527b2252cf2f2c99c9a83b2ea4488fe5f3b7ee9c61e95a4de107816116df0027f87675638aac197200637ad3165c8ea6c0355caaa22600992bab55854d4246aa835b68299fc0be83e755735e66020a838846e187382510d7556989d7dc7a149b16d3b40016eb1ef9b7d936aef8104c9497178abdb97aa32e97891e658b9aa7958760313e1250986a81db447d4d91da377af92af306f59cf981291e1f3234de04123cc73f01a2ce35d15670362a381d36bc9c6c7d7c124cd29ecd423b3d16bb3b632ac39b1ef77bd165739bd6746e81ff00112ba7832ed8f34e9b2ff0eb3db7f0d50e926993c37b7ce47ecbe8586a41cf93bc415f19c830e45467be1f85f59c931db2435fe2a73b3cfa69c7bf0eccd84513aec0bee96199991b8df72f5f99b5bd6dba76102c796eee4d2b60c3c76a5d5321a7be3c02bdd3d637d93bab7c576a5c389b3759b37f328ca9421b609852cb58d43e69886b1b0355397aecedf884b88aa180b9c40004927401626ae24e3311b570c6821a38366e48e27de8abe9366cfa954d383f0d84697da77137bc1f45e60b14d630b5adbbb527551e3d15ce1ae11b2f1c24faa7d87c3cbc38ee9b721a8f33e09364b5699223e6e056ab0d4e6f1bc8f7e12a3c6cf69b94f85f8d7ecb83877f6ca6d823b4db6b129166df4f3fb269964884e5fc9197ea32ac5bd178bab9bd972aa8098bc48d900d92fa750894557a7b4c4aeedb1d113ecefd19d3ab6ba3705546ed4714b03cecc429e58093c149e9e60eabaa34173a646f33bcce8a9c7386e31fbfdd114694580eaf5a08d4dc9b70174ab35c4319226fc05c8eee2a6b684999b891b204f3e3c166b1261c5a3acf3e438ad357a4f70dec6f8bff000d4a860d930d3b2dde4ea79f1294b27b5596fa0f85c1c30926f1e6963703b6f922eb4951e0b7e1d16923ea79fb2bf0596427e565dae63d6a97655808aad3c16d05096a130b830083ef9fbe69b0d129d8bd2ba19c54a6dd9370343bd0b5b3e7ce8576219aa01ed55e553d0a39fd43612a38ec56cd373dc64804fec8300cab332a01ec7533a39a4797e6112efd8cbe9f39c6ed493c75e73742e1b1c5874b77f94a6ad6973013adc1ed060f9ca06be1815db2479f6d1f4b160c11dab4f957489e236b4dfe92b0d45a586fa275847422e32fb39958fa7548a818666fff00a98fb27184a1023cd62fa338c8686b8da4472fed7f15b9c23bc3558e5c7e35a4cf712ab4ed2bd56b1a5dc805cb3f1b4882893b1b250af05c76404ee9e1870578c301a0babd1da170b83801154e901badc38f256bd93be15356a06eb2397d47f0121374af33613d565b59dc206a4ef23c165b3663e946c53692413b5a868b1d75d085a6ad897540e21a5acd06803bbef3bed085c76189c375ac482d1d8483e83cc29b8ee3699698aa78b25e03bac779b003b07dd3ec2658d7892e9e5f9082665c24b8589521b4c32d3042aff9f70a7fe8d5682865ed6b600517510bccbf3115441b3c6a3ee3922dec58dc75d56f3297b80df65eb6b29d4082ab64bd296d67a14a81a92bc79b2365a7acd57ac32e55b2611d80a1a1442d32199604d3ad51b1d579f88defb3c7f541ff00724f568dd6c7a5ef687d16fd5150f700d9f3859fa8c057771dde2e1e59acae8abe1c98455069688dde8b9acba20056cce32ca90d1da7ecb7d91e2b6a9807503c97cea9bb6698ed3f65a4c8f191b1ef7a2cdcd0974d936a9124f25c85c438965bdf05cb86db2ba35076960bda60aae99de546b63765a48049dc3895b6d1a518dc541224ce822e498bc0df1215186a1f109db6f547d3a8278b8fd47c979446ccbea5dee993c2fa0e017627121a3ab2ede4cc0f2bf9855861bee9e596ba89e28b5b2f7986b6c00d07ee7481749f1f980a9a9868d1a22ddbcd43121d50cb8d8683709e0154ec33616b31ef759dcbe22b351b1f37903f7543f65da107b3f0bcc46146eb704057c25880482781f4569dadd82d70734dc689ee5b8ef88223ac351c79858a19854a462a02e1c77f8a6982c635e43e9bbac2fcc2cb3c264d38f92e35a8a8deeed42d4a09865d8d155b0443c6a3ee392b9f446ab932c6ceabbb1ce59d107f00e953a984205d381650ac4110a74ad9661f0d29b3698685551a77edb78ab2b3b529ce8af6f9e749ab138ea7c031c3c41fc054cd95dd21a7ff005b4ffd27d0aab6576717eae0e6fde87636e558d175c45d5b49b255b34f1ce86b07127ec986031105bda12cce1db229f63bff0055d97d59737804c9f45c062b6816f03e5a85cb359466061ce1fabec572c73e1f2bb95a639ea69f4914821b134c36fefde8a74eb7141e635ad0961ab559750363aa82c3cf44054a9d582acc75dade495626b42e8629d4aea87574254aeaaf888034561bd58ea6c7db6803e0836625add42aeb63f0eeb3816f30803aa65c5c21c03c71b4aca67390d5a07e2d19817e63b9317e5cd7de9629c3bc8285ad4f30c3f59aff008ecde3531ea950b3a3dd24db700eead51e0ef7c16f70d8c151b22c778e057c6f1f55959c5d49a69d517d8fd446a1bc1dcb7f6eba7e887490ba1ae3d7163fcedfc8597261e51af17278dfa6e6a150a4d275d42bd90448d0e886af58b5c0812378100c77f05c77a77cfa14372aeb3d7ada92278c797f7f25022e9ec321d27a3ff5344ff2bbd100e129cf49c4d7a7c98e3e2e012760f98702575f17eae1e6fdd43d5b85d541e215d866ad5887e919ff00b7feefb20a962c346c8bb9c2072e657bd2bc4c3a98fe53ea12ec1022e6ee3e491b4f97548eacf6f6ae42e04dd7264facb6b024ca559de21e23644f19de2f607c112ca05c6df2a1b35e3bbf0b0e29f936cfd163319b4dd6fc38724af175e2d2a18d25ae046f9547f16d759d62b7ac553ab9f7aa9b2b421ab360eaa0c7240c4635bbc48560af873f3001002178fa4d3b93036a6170cef96ab5a79aa5b83734cd3ac3faadea86197b0ee53190b0f1f140519a65c6a759ec978b8a94e36c4718f9bbd66714ed978acc3ab88745a1e35b6e9d7c56ca9648c69b79a13a4394ed31ce03ad1d6e24b6ec776ead3c9dc9067dd14cf05466c937fba7a57c7f22cc4d2782be9d97e64d7b45f51239f2ed0b979b8ffd4757072ff9a67447576ad7711adc59a6e3bcab18529a15e1ee116b19e77b7a28e6598fc3640f98e9c8712b0c65b751d395926e94e7188daaee76e1b2c1dc6fe64f8206a362a1e063d1476a4723f957e25b2011ac0fbaf4319a9a79b965bbb0d545d5f42d7dcab37bab23abd8991074a67e2d37716903b41fdc2a70e0c233a46d01ad3bc3afde3f6096d2c5a4479970bae4b29632345c8d9bee346ab6606a77249993a641d6eaaa7888ab170277ab73432646e59717b699fa65b115b68ca0311483afbd307539240e250d5f0c755b5645b70ad6d49522e8d429b69876891bc63c6f453610bf0e1731d082152e170a74f1c07ccaa189d9d7457d1c661cea04ef4c08a59cd3fd24a2a9639b52c6988e6a9a7530c7ea01174e8d23a546f7a61f30ce70468d77b383adfe9376f914e7a3f8e0e1f0dfa1d0ef07710b539ee46dad45c25aea8d04b0822675d99e0748e6be786954a2fd97b5cc7707020ff653606d462dd4c90f322090edf6d7b7721df58546ed83ccfa4f888ef51c15615e9c124482d71fe57089f18f6144605d4a4120980246840dfde96a7c2b76fb565f64d288960293d47689b65ae911cbeea9211a2e42b2ad99cc29d66ecde0aaf12e219ccc03bc7045366ba4b88f95bbcdcf60b0fbf825745f2adc7d56baaba741d51d82df95d4f0b4ce8f23c1042a8b6572f68e1c8d2b0ef6af52d0dbec4da20c5a48b031af6a5d9bd42d748b08823df6a72c106f6093670ff9a78acf8d5933afc402fb58c79a25b5e6c6c5098ca1691aee281a78d330ff0015aa4cebd005035b0ee6dc688ba388e28a00147b0594b100d8d97afa5c159570d33c42160b77a03d36b1165e9cadafb82a724eb75e30b9865be080a4e4b1c5594b2b3fa884c28e7407cedd15a7a40c02453947415e172b7feb289cd325755a2e611b4402593a870d20ee9d10cce91563f2d18ee5753ce3127e81e09f418bc0547d1a8241106e0dbb885b365215581c0ea37a9e27125c22a516bffda27c55585a2ea4f0d3b229bc4b340e9ded22c09d2e35e496812629b060ee44e5f523445e71853f311c8a1306d8404b0b8adaeb3be606366f670d49f7a42af1ce9040937111a93681e281ad8a8af234737adc24687c2de09af45c7c7c4b6dd564bbb48b37ccf929b751523e7ae264ceb267b558c705beff0010fa2d04e269b40ffc8d02c376d8fbf8ac05317ba265328566a8962e5d4990b91a27df1b4e776fb71d02458fa5b45c0e80a7cc782e02f046bc48feeb2f9ae20b5ce0389f551c5f2bcc9f303092622a8e098e25c5c8438692b5417e131af698225be613aa18c8e61526886364acfd4cccb2a5aedde3f1cd20dad3a8d75c2955c302b3d43101c039a63df04653cd1edd47927b0bead273398e23550f8c0fef64451cd98ed42bf6e91130100bdcd055b4eb318d718161a73fdd142b531a003b5078cc651823685f50013e41012c2e6ae73831cd0d304d8dac6081c46ed3509832a54920b8472f4297e0b08c6f59a2e7793b523b4eed11cdd75bf977a60d683e46896e7d85a6ff0083f12a169654da0d6804bc70d46ce9aa96679afc1a661b26da713c7920b25cbdcf77c6ab25c74077260e31d45ce05d1d576bc5bddc39acbd57ec92dde09056ea9540d8075e1aa43d25c93ffd68b774b9a3d5a3ede095823218c747695b7e80608370eeac7e673881d8db7aed2f9d54aa5e445c920347124dbcd7d6b2dc2fc1a0ca2756b4031fa8ebe72b9f92ea36c20dc43dae639aff009082d8e20882be2dd21ca9d86ac586e0ddaefd4dfcf15f61d9d24f5770e3de976799252c63431e764b49d978171c4730782cf8f2f1bd9e58edf1c7d55cbe8d957f8683e33be2d4daa23e58b39c637fe90396ab96d7971899c5956fb098c6870da1b220ee9ddfb2ca672d97b88de49f15a2653d9826fc0fa8292e7661e7dee4b8af762739d111a6a8aaf015f897f04871af256c8539a6366c12cc361c92aff84494cf2ec2c90901583c196b41060c6aab6b81241f9bd79a7b5190d487194f53a14f411a940eef7daa0daee6d8a8e0733693b0fb1dc771fdd337500e4b402b31acd08f31e6bd766341a2c0b8f002de2a1532f6926ca1fc206a3b0f2866cedb114c8a7bc4dfb40fb276cc4c896e87428114d8c6ed3b44255cc8361d4c4b64023792ee1cc093dc991fb1db8f7cde7c510712401b87a70129552ac1c2469e9dbcd5c3144586bebfb72540ff00034e3ac4dca64cac3ea596cbeaecb88da2493266e472e63d37f12cf08e7d778a74b4fa9fb8721cd2b949374f1c6e5750263329a2ec650ad4dbb3fe645400754b802e0e8dce917e33c42d0e209db22752741e09fe1fa39403000deb40ebfd52044f9e894e6395d56179d9db1f4ecde6dc372e4e5be576e9c71d426a9565d0368f12744e32fc0ed41737b3555653943e769cd74f0bc0f15a4a18723742cfbad26323ca14217231b497aabc4f6ccbb0ce3d60247678f92cde6e3ace5afc2d7206b064739bde6eb2d9c37aeeedf55b717b72e7e99baa9762637dfd51d8bb4a4d89712b6648170980b4794e0c81b47b90192e533156a7cbb86f773ec5a27986f329c80163ea5a123c53b54cb30a9aa458cad6450458d3d64cf28ce8b21afbb78ef1da94d53254dad526df615a1e0907551a984bac9e5b99be89b5dbc3f09eb7a574e3acc24f00aa52539960ea39db2086b06a4d801cd2dc43dbf1194d976531aef738eae286cd3367d6749eab068c1a769e279a96574bea3bd2339755d805e370b8e28ba3896d468730d8f883c392558bbb3b4fa2270f445264ef8f1412f6b65fb00ded246ebf1e2be91d1ca029b442f9ff004729df6cea4adf60ab80172679eebb78f0f1c5aaa3595df1524a38956ff1296d46db61786a849df8ce6aa76608d968ecd55c901c72e4bc8f4adc21ac22d3337d7448b3cb543d8172e5af0fece5cfd33399a1325a2d7d76870045cc6e90172e5d2c8feaba5c41e3f70a35ddaf685cb930458e7582478f365cb94d04e35453178b92373d0af2bd5c8813c23417b41d2531a8ed9ae5a2cd9d3768178b932a6d87682592adcc8f54f77aae5c803b20f942d260ea1e2b972f36fb7a73d1bd079e2ae73cae5ca8be55d4715582b972020e715e2e5c907fffd9, '1'),
('S128-429-825', 'Meghana', 'Chandarn', 'female', '01/24/2020', 'Sdsadsdsadasd', 'meghana4@gmail.com', '2323', 'Philosophy', 'Philosophy Phd', 'e10adc3949ba59abbe56e057f20f883e', 'student', NULL, '1'),
('S234-170-579', 'Xx', 'Xx', 'female', '04/25/2020', 'Eeqweqwewqe', 'xx@gmail.com', '32323', 'Zz', 'Biometric Cerificate', 'e10adc3949ba59abbe56e057f20f883e', 'student', NULL, '1'),
('S237-543-020', 'Nishan', 'Jas', 'Male', '12/09/1995', 'Erwefsefdsf', 'Nishan@gmail.com', '1232432', 'Biomedical', 'Biomedical Diploma', 'd5cb861754c652f6c2070b0a42fcdaf1', 'student', NULL, '1'),
('S518-384-238', 'Sss', 'Ddd', 'female', '11/09/1992', 'Ssddsdsd', 'ss@gmail.com', '907096', 'Computer Science', 'Computer Science Diploma', 'e10adc3949ba59abbe56e057f20f883e', 'student', NULL, '1'),
('S562-495-080', 'Hhhhh', 'Hhhhh', 'male', '04/15/2020', 'Hhhhh', 'hhhhh@gmail.com', '678900987', 'Biometric ', 'Biometric Cerificate', 'e10adc3949ba59abbe56e057f20f883e', 'student', NULL, '0'),
('S721-636-402', 'Rosh', 'Nishan', 'female', '23/04/1997', 'Dfasdfdsfsfds', 'rosh@gmail.com', '34543543', 'Computer Science', 'Computer Science Diploma', 'e10adc3949ba59abbe56e057f20f883e', 'student', NULL, '1'),
('TR041-265-321', 'Dd', 'Ddd', 'male', '04/01/2020', 'Fsdfsdf', 'dd@gmail.com', '32424', 'Biomedical', '', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', NULL, '1'),
('TR319-128-649', 'Nizzy', 'Diax', 'Female', '09/06/1965', 'Ffdsfdsfdsf', 'Nizzy@gmail.com', '4214324324', 'Electrical Engineering', '', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', NULL, '1'),
('TR472-707-539', 'Ff', 'Ff', 'female', '04/01/2020', 'Cvcvcxv', 'ff@gmail.com', '3434', 'Chemical Engineering', '', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', NULL, '1'),
('TR541-462-351', 'R', 'R', 'female', '02/27/2020', 'Gdf', 'r@gmail.com', '54', 'Philosophy', '', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', NULL, '1'),
('TR687-767-129', 'Meghana', 'Sfds', 'Female', '01/30/2020', 'Damansara', 'ds@gmail.com', '9080', 'Philosophy', 'Philosophy Phd', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', NULL, '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_alerts`
--
ALTER TABLE `tbl_alerts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `tbl_assessment_records`
--
ALTER TABLE `tbl_assessment_records`
  ADD PRIMARY KEY (`record_id`);

--
-- Indexes for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_departments`
--
ALTER TABLE `tbl_departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `tbl_examinations`
--
ALTER TABLE `tbl_examinations`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `tbl_notice`
--
ALTER TABLE `tbl_notice`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `notice_id` (`notice_id`);

--
-- Indexes for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_alerts`
--
ALTER TABLE `tbl_alerts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tbl_notice`
--
ALTER TABLE `tbl_notice`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
